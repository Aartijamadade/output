a=input(" enter the first no")
b=input(" enter the second no")
c=int(a)+int(b)
print("addition",c)
